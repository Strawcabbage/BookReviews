package com.bookreviews.repository;

import com.bookreviews.entity.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {

    public List<User> findByUsername(String displayName);

}
